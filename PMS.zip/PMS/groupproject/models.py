from django.db import models
from urllib import request
from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import User
import datetime
import os

from django.contrib.admin.views.decorators import staff_member_required
# Create your models here...
class addproduct(models.Model):
    productname=models.CharField(max_length=50)
    productprice=models.IntegerField()
    productidnumber=models.IntegerField()
    productstock=models.IntegerField(default=0, blank=True, null=True)
    productdescrition=models.TextField()
    productimage=models.ImageField(upload_to="static/addproduct/image",default="")

class doctoradd(models.Model):
    doctorname=models.CharField(max_length=50)
    specialization=models.CharField(max_length=50)
    hospitalname=models.CharField(max_length=50)
    address=models.TextField()
    fess=models.IntegerField()
    doctorimage=models.ImageField(upload_to="static/doctor/image",default="")

class bookappointment(models.Model):
    # doctor field, availble doctor name, time date
    # patient payment conform name id slot
    doctorfield=models.TextField()
    availabledoctor=models.TextField()
    time=models.TimeField()
    type=models.CharField(max_length=100,default="offline")

class patientappoint(models.Model):
    username=models.CharField(max_length=100,default="")
    patientname=models.CharField(max_length=100)
    doctorname=models.CharField(max_length=100)
    doctorspecialization=models.CharField(max_length=100)
    slot=models.TextField()
    description=models.TextField()
    doctorid=models.IntegerField()
    type=models.CharField(max_length=100,default="offline")
    
class orders(models.Model):
    productidnumber=models.IntegerField()
    quantity=models.IntegerField()
    productname=models.CharField(max_length=50)
class verifydoc(models.Model):
    username=models.CharField(max_length=100)
    name=models.CharField(max_length=100)
class cart(models.Model):
    productname=models.CharField(max_length=50)
    productprice=models.IntegerField()
    usercart=models.ForeignKey(User,on_delete=models.DO_NOTHING)
    username=models.CharField(max_length=50)
    quantity=models.IntegerField()
    

    